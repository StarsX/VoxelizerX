#pragma once

#include "resource.h"
#include "SurfaceVoxelizer.h"

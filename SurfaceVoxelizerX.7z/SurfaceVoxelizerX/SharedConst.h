#define GRID_SIZE	64
#define SHOW_MIP	0
